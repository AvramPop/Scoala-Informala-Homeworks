package net.vompi;

/**
 * Room simulates a house's room, that has known dimensions.
 *
 */
public abstract class Room {
    public abstract double getArea();
}
